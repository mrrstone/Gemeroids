Gemeroids v1.2.0
By Mr. Stone

This update of the classic space shooter "Asteroids" offers many improvements over the original, including visual and audio effects, a new 'shield' game mechanic, and high scores local save system.  This was created as a tutorial for Game Programming and Design, a Tech Apps course offered through Garza Online (http://www.garzahighschool.net).